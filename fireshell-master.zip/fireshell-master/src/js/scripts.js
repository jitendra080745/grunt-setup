(function ($, window, document, undefined) {

  'use strict';

  $(function () {
    // FireShell
  });

})(jQuery, window, document);
